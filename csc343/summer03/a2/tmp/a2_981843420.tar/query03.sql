SELECT COUNT(playerID) AS numCanadianPlayers \
FROM Players \
WHERE birthCountry = 'Canada'
