SELECT franchName, franchID \
FROM Franchise
