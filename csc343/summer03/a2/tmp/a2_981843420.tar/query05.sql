SELECT COUNT(playerID) AS numPlayers \
FROM Players \
WHERE bath = 'B' AND throws = 'L'
