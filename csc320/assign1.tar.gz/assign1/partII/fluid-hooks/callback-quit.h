// Callback specifying what happens when a user chooses
// "File/Quit" from the menu 

exit(1);
