// WARNING: DO NOT MODIFY THIS FILE EXCEPT WHERE EXPLICITLY NOTED
//
#ifndef IMDRAW_H
#define IMDRAW_H

#include <FL/Fl.h>
#include <FL/Fl_Window.h>

#include <FL/gl.h>
#include <FL/Fl_Gl_Window.h>

#include <deque>

#include "../Texture.h"

#include "imageprimitive.h"

using namespace std;
////// PUT YOUR CODE (IF ANY) BETWEEN THESE LINES ///////

//Define some constants to represent program state.
#ifndef D_POINT
#define D_POINT 1
#endif

#ifndef D_LINE
#define D_LINE 2
#endif

#ifndef D_RECT
#define D_RECT 3
#endif

#ifndef D_CIRC
#define D_CIRC 4
#endif

#ifndef D_POLY
#define D_POLY 5
#endif

/////////////////////////////////////////////////////////

class ImDraw : public Fl_Gl_Window {  
	public:
		// The class constructor 
		ImDraw(int x,int y,int w,int h,const char *l=0);

		// The widget class draw() override.  The draw() function
		// initializes GL for another round of drawing and then calls
		// specialized functions for drawing each of the entities to be
		// displayed.
		void draw();

		// This is the event handling routine. All UI events go through
		// this routine, which can choose to pass them on to the default
		// handler or handle them itself.
		int handle(int event);

		// Set the image to be displayed on the GL canvas. The image will
		// be displayed the next time the method draw_image() is called.
		// The image must have a resolution of at most 1024x1024. If
		// larger images are needed, the file Texture.cpp must be
		// modified accordingly.
		void set(VImage im);

		// Draw the image on the GL canvas. This method is called by the
		// draw() method.
		void draw_image();

		// convert an (x,y) position given in GL canvas coordinates
		// (eg. generated through a mouse event or used to draw a vertex
		// with OpenGL) to an integer (row,column) coordinate
		// corresponding to a pixel in a Vista image
		int gl2vista(double glx, double gly, int& r, int& c);

		// convert the (row,column) coordinate of a pixel in a Vista
		// image to an (x,y) position on the GL canvas.
		int vista2gl(int r, int c, double& glx, double& gly);
		void resize(int x, int y, int w, int h);

		////// PUT YOUR CODE (IF ANY) BETWEEN THESE LINES ///////
		void drawRect(int r1, int c1, int r2, int c2);
		
		/* Returns the value of a symbolic constant representing the
		   current program state. */
		int getDrawingState();

		/* Sets the current program state to the value passed as a
		   parameter. */
		void setDrawingState(int drawingState);

		/* Check whether the last scene object in the queue is a
		   polygon. If it is, and the polygon is not complete, 
		   complete the polygon. */
		void checkForPoly();

		/* Insert a scene object at the back of the queue. */
		void sceneObjectsPushBack(ImagePrimitive *myObj);
		
		/* Returns the string representation of all objectsin the scene. */
		string sceneObjectsToString();

		/* Clear all the objects in the scene. */
		void clearScene();
		
		/* If there is a line in the scene that is closer
		   to (x,y) than any other line and closer than 
		   some threshold, returns the pointer to that line,
		   otherwise returns null. */
		ImagePrimitive* nearestLine(int x, int y);
		
		
		/* Remove the most recently added object from the scene. */
		void sceneObjectsUndo();
		
		/* Returns true if there are no objects in the scene. */
		bool sceneIsEmpty();
		/////////////////////////////////////////////////////////

	

	private:	
		int width, height;
		int im_height, im_width;
		double aspect_ratio;
		double magnification;
		Texture *imTexture;
	 
	 	
		/* This pointer is used to specify what line is being dragged. */
		ImagePrimitive *dragLine;
		
		/* Starting coordinates for line dragging. */
		int startX , startY;
		
		/* Flag specifying whether cursor shape has been set. */
		bool cursorSet;
		
		/* Current state. Can be one of D_POINT, D_LINE, D_RECT, D_CIRC, D_POLY
		signifying the drawing of a point, a line, a rectangle, a circle, or
		a polygon respectively. */
		int drawingState;
		
		/* A deque of objects in the scene. */
		deque<ImagePrimitive*> sceneObjects;

		////// PUT YOUR CODE (IF ANY) BETWEEN THESE LINES ///////

		// Parameters of a rectangle drawn over a Vista image.
		// Rectangle expressed as the (row,column) coordinates
		// of two opposing vertices of the rectangle. Coordinates
		// are assumed to be Vista image coordinates
		int rect_r1, rect_c1, rect_r2, rect_c2;
		// Flag that is true if the user has begun drawing a rectangle
		int rect_drawn;

		/////////////////////////////////////////////////////////
};
#endif
