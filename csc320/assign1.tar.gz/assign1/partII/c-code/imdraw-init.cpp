// WARNING: DO NOT MODIFY THIS FILE EXCEPT WHERE EXPLICITLY NOTED


#include <math.h>
#include <iostream.h>
#include "imdraw.h"
#include "../glutils.h"

////// PUT CODE USED BY CONTRUCTOR (IF ANY) BETWEEN THESE LINES ///////
///////////////////////////////////////////////////////////////////////

// Constructor initalization routine
ImDraw::ImDraw(int x,int y,int w,int h,const char *l)
	: Fl_Gl_Window(x,y,w,h,l)
{
	// w and h are the width and height of the OpenGL canvas 
	width = w;
	height = h;
	im_width = width;
	im_height = height;
	aspect_ratio = 1;
	magnification = 1;
	// Initially, the allocated texture memory contains no data
	imTexture = NULL;

	////// PUT YOUR INITIALIZATION CODE (IF ANY) BETWEEN THESE LINES ///////
	
	//current state
	drawingState = 0;

	/* Line being currently dragged. */
	dragLine = NULL;

	/* Starting coordinates for line dragging. */
	startX = 0;
	startY = 0;

	/* Flag for setting cursor shape. */
	cursorSet = false;
	
	// user has not drawn anything yet
	rect_drawn = 0;
	rect_r1 = rect_c1 = rect_r2 = rect_c2 = 0;

	////////////////////////////////////////////////////////////////////////
};


