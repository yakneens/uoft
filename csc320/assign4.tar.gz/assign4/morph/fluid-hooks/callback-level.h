setLevelOfDetail(levelOfDetail->value());
imagePanel->redraw();
