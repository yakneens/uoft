/* Clear the scene of all objects. */
imagePanel->clearScene();

/* Redraw the scene. */
imagePanel->redraw();
