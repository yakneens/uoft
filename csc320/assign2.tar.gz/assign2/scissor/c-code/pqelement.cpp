#include "pqelement.h"


PQElement::PQElement(Node *imageNode, double priority){ 
	this->imageNode = imageNode;
	this->priority = priority;
	this->valid = true;
}

double PQElement::getPriority() const{
	return this->priority;
}

void PQElement::setPriority(double priority) {
	this->priority = priority;
}

bool PQElement::getValid() const{
	return this->valid;
}

void PQElement::setValid(bool valid){
	this->valid = valid;
}

Node *PQElement::getImageNode() const{
	return this->imageNode;
}
