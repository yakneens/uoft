// WARNING: DO NOT MODIFY THIS FILE EXCEPT WHERE EXPLICITLY NOTED
//
#ifndef IMDRAW_H
#define IMDRAW_H

#include <FL/Fl.h>
#include <FL/Fl_Window.h>

#include <FL/gl.h>
#include <FL/Fl_Gl_Window.h>

#include <deque>

#include "../Texture.h"

#include "imageprimitive.h"
#include "node.h"

using namespace std;
////// PUT YOUR CODE (IF ANY) BETWEEN THESE LINES ///////

//Define some constants to represent program state.
#ifndef D_POINT
#define D_POINT 1
#endif

#ifndef D_LINE
#define D_LINE 2
#endif

#ifndef D_RECT
#define D_RECT 3
#endif

#ifndef D_CIRC
#define D_CIRC 4
#endif

#ifndef D_POLY
#define D_POLY 5
#endif

#ifndef D_SCISSOR
#define D_SCISSOR 6
#endif

#ifndef DISPLAY_IMAGE
#define DISPLAY_IMAGE 1
#endif

#ifndef DISPLAY_GRAD
#define DISPLAY_GRAD 2
#endif

#ifndef PI
#define PI 3.14159265
#endif
/////////////////////////////////////////////////////////

class ImDraw : public Fl_Gl_Window {  
	public:
		// The class constructor 
		ImDraw(int x,int y,int w,int h,const char *l=0);

		// The widget class draw() override.  The draw() function
		// initializes GL for another round of drawing and then calls
		// specialized functions for drawing each of the entities to be
		// displayed.
		void draw();

		// This is the event handling routine. All UI events go through
		// this routine, which can choose to pass them on to the default
		// handler or handle them itself.
		int handle(int event);

		// Set the image to be displayed on the GL canvas. The image will
		// be displayed the next time the method draw_image() is called.
		// The image must have a resolution of at most 1024x1024. If
		// larger images are needed, the file Texture.cpp must be
		// modified accordingly.
		void set(VImage im);

		// Draw the image on the GL canvas. This method is called by the
		// draw() method.
		void draw_image();

		// convert an (x,y) position given in GL canvas coordinates
		// (eg. generated through a mouse event or used to draw a vertex
		// with OpenGL) to an integer (row,column) coordinate
		// corresponding to a pixel in a Vista image
		int gl2vista(double glx, double gly, int& r, int& c);

		// convert the (row,column) coordinate of a pixel in a Vista
		// image to an (x,y) position on the GL canvas.
		int vista2gl(int r, int c, double& glx, double& gly);
		void resize(int x, int y, int w, int h);

		////// PUT YOUR CODE (IF ANY) BETWEEN THESE LINES ///////
		void drawRect(int r1, int c1, int r2, int c2);
		
		/* Returns the value of a symbolic constant representing the
		   current program state. */
		int getDrawingState();

		/* Sets the current program state to the value passed as a
		   parameter. */
		void setDrawingState(int drawingState);

		/* Check whether the last scene object in the queue is a
		   polygon. If it is, and the polygon is not complete, 
		   complete the polygon. */
		void checkForPoly();

		/* Insert a scene object at the back of the queue. */
		void sceneObjectsPushBack(ImagePrimitive *myObj);
		
		/* Returns the string representation of all objectsin the scene. */
		string sceneObjectsToString();

		/* Clear all the objects in the scene. */
		void clearScene();
		
		/* If there is a line in the scene that is closer
		   to (x,y) than any other line and closer than 
		   some threshold, returns the pointer to that line,
		   otherwise returns null. */
		ImagePrimitive* nearestLine(int x, int y);
		
		
		/* Remove the most recently added object from the scene. */
		void sceneObjectsUndo();
		
		/* Returns true if there are no objects in the scene. */
		bool sceneIsEmpty();

		/* Converts an rgb image to grayscale. */
		VImage rgbToGrayscale(VImage img);

		/* Returns an image of zero crossings of the second
		   derivative of img, using gaussian filter of
		   standard deviation = sigma. */
		VImage zeroCrossings(VImage img, int sigma);

		/* Returns an image of gradients of pixels
		   in img. */
		VImage gradient(VImage img);

		/* Returns an image of gradient magnitudes of pixels
		   in img. */
		VImage gradientMagnitude(VImage img);

		/* Returns the maximum gradient magnitued in img. */
		VDouble gradMagMax(VImage img);

		/* Returns the current display state. */
		int getDisplayState();

		/* Sets the current display state. */
		void setDisplayState(int state);

		/* Initialize path finder data structures. */
		void pathFinderInit(int nrows, int ncols);

		/* Reinitialize path finder data structures. */
		void pathFinderReInit();

		/* Destroy all resources used by the pathfinder. */
		void pathFinderDestroy();

		/* Compute the link costs for image im. */
		void computeLinkCosts(VImage im);

		/* Compute the link cost between nodes n1 and n2. */
		void linkCost(int index, Node *n1, Node *n2, VImage zeroCross, VImage gradImg, VImage gradMag, VDouble maxMag, bool diag);
		
		/* Compute minimal path costs given a seed point. */
		void computePathCosts(int seedX, int seedY);
		
		/* Returns the image nodes of this image panel. */
		Node *getImageNodes();
		
		/* Returns this width of the currently displayed image. */
		int getImageWidth();
		
		/* Returns the height of the currently displayed image. */
		int getImageHeight();

		/* Returns an image containing the boundary described by
		   boundary. */
		VImage getBoundary(ImagePrimitive *boundary);
		
		/* Returns an image containing an alpha matte based on the
		   boundary contained in boundary. */
		VImage getMatte(VImage boundary);

		/* Returns the string representation of the boundary
		   vertices contained in the scene. */
		string writeBoundaryVertices();

		/* Returns the string representation of the boundary
		   seed points contained in the scene. */
		string writeBoundarySeedPoints();

		/* Writes the current image matte to file. */
		void writeMatteToFile(char *filename);

		/* Writes the current image gradient image to file. */
		void writeGradToFile(char *filename);

		/* Writes the current zero crosssings image to file. */
		void writeZeroCrossToFile(char *filename);

		/* Writes the current link costs image to file. */
		void writeLinkCostsToFile(char *filename);
		/////////////////////////////////////////////////////////

	

	private:	
		int width, height;
		int im_height, im_width;
		double aspect_ratio;
		double magnification;
		Texture *imTexture;
	 
	 	
		/* This pointer is used to specify what line is being dragged. */
		ImagePrimitive *dragLine;
		
		/* Starting coordinates for line dragging. */
		int startX , startY;
		
		/* Flag specifying whether cursor shape has been set. */
		bool cursorSet;
		
		/* Current state. Can be one of D_POINT, D_LINE, D_RECT, D_CIRC, D_POLY
		signifying the drawing of a point, a line, a rectangle, a circle, or
		a polygon respectively. */
		int drawingState;
		int displayState;

		/* A deque of objects in the scene. */
		deque<ImagePrimitive*> sceneObjects;
		
		/* An array of image nodes representing pixels of the image. */
		Node *imageNodes;
		

		VImage grayImage, gradImage, zeroImage;

		int lastScissorX, lastScissorY;
		bool firstScissorClick;
		////// PUT YOUR CODE (IF ANY) BETWEEN THESE LINES ///////

		// Parameters of a rectangle drawn over a Vista image.
		// Rectangle expressed as the (row,column) coordinates
		// of two opposing vertices of the rectangle. Coordinates
		// are assumed to be Vista image coordinates
		int rect_r1, rect_c1, rect_r2, rect_c2;
		// Flag that is true if the user has begun drawing a rectangle
		int rect_drawn;

		/////////////////////////////////////////////////////////
};
#endif
