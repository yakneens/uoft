#include "pqelement.h"


PQElement::PQElement(Node *imageNode){ 
	this->imageNode = imageNode;
}

double PQElement::getPriority() const{
	return this->imageNode->getCost();
}

Node *PQElement::getImageNode() const{
	return this->imageNode;
}
