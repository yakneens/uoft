#ifndef PQELEMENT_H
#define PQELEMENT_H
#include "node.h"


// Define a class that defines the elements of the priority queue
class PQElement {
    
	public: 
		PQElement(Node *imageNode);
		double getPriority() const;
		Node* getImageNode() const;
		bool less(PQElement &n1, PQElement &n2)
				   { return(n1.getImageNode()->getCost() > n2.getImageNode()->getCost()); };
		bool operator<(const PQElement &n1) const 
				   { return this->imageNode->getCost() > n1.getImageNode()->getCost(); };

	private:
		Node *imageNode;
};

#endif