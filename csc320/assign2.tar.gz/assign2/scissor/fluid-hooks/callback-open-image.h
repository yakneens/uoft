// Callback specifying what happens when a user chooses
// "File/Open Image" from the UI menu 

{
  int OK=0;
  VAttrList attrs1;
  VImage *im1;
  FILE *fd;
  char *fname;

  fname = fl_file_chooser("Open Image...", "*.v", "");
  if (fname == NULL)
	  OK = 0;
  else {
#ifdef _WIN32
	  fd = fopen(fname, "rb");
#else
	  fd = fopen(fname, "r");
#endif
	  if (fd)
		if (VReadImages(fd, &attrs1, &im1)) 
			OK = 1;
  }
  if (!OK)
	 fl_alert("VReadImages: Error opening image file. Image(s) not displayed.");
  else {
     if (im != NULL) 
           VDestroyImage(im[0]);
     if (attrs != NULL)
	       VDestroyAttrList(attrs);
	 im = im1;
	 attrs = attrs1;
	 set(im[0]);
  
	/* Convert image to grayscale. */	
//	VImage grayImg = imagePanel->rgbToGrayscale(*im1);
	//set(grayImg);
	
	/* Compute zero-crossings of the second derivative. */
//	VImage zeroCross = imagePanel->zeroCrossings(grayImg, 1);
	
//	FILE *outFile = fopen("zeroCross.v", "wb");
//	VWriteImages(outFile, NULL, 1, &zeroCross);
	/* Compute the image gradient magnitude. */
//	VImage gradMagImage = imagePanel->gradientMagnitude(zeroCross);

	/* Compute the maximum gradient magnitude in the image. */
//	VDouble maxMag = imagePanel->gradMagMax(gradMagImage);
		

	imagePanel->pathFinderInit(VImageNRows(*im1), VImageNColumns(*im1));
	imagePanel->computeLinkCosts(*im1);

	
//	cout << maxMag; cout.flush();

/*	if(imagePanel->getDisplayState() == DISPLAY_IMAGE){
		set(grayImg);
	}else if(imagePanel->getDisplayState() == DISPLAY_GRAD){
		set(zeroCross);
	}
*/
//	imagePanel->computePathCosts(1, 1);
//	imagePanel->pathFinderDestroy();
  }

	
	
	/*	cout << VImageNFrames(gradImgXY2) << VImageNViewpoints(gradImgXY2) << VImageNColors(gradImgXY2) << VImageNComponents(gradImgXY2);
	cout << VImageNBands(gradImgXY2);
	cout.flush();*/
}
