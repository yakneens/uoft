// main.cpp : Defines the entry point for the console application.
//
// This is the top-level function of an example program that displays a Vista
// image on an fltk OpenGL panel

#include "stdafx.h"
#include <stdlib.h>
#include <iostream.h>
#include <stdio.h>
#include <vista/file.h>
#include <vista/VImage.h>
#include <vista/option.h>
#include <vista/mu.h>
#include "ScissorUI.h"

// Routine for processing command-line arguments (defined below)
void processArgs(int* argc, char** argv, ScissorUI& window);
// Routine for processing the '-im' command line argument
void openImage(char* progname, char* filename, ScissorUI& window);
// Routine for processing the '-cmd' command line argument
void processDrawingCommands(char* progname, char* filename, 
			      ScissorUI& window);

// Program entry point
int main(int argc, char **argv) {
     // Initialize fluid
     Fl::visual(FL_INDEX || FL_DOUBLE);

     // Create the UI windows for the interface
     ScissorUI *window = new ScissorUI;

     // Display the UI windows
     window->show();
     
     // Process command-line arguments (if any)  
     processArgs(&argc, argv, *window);

     return Fl::run();
}

// Routine for processing command-line arguments
void processArgs(int* argc, char** argv, ScissorUI& window)
{
     // Variables that will hold values of command-line arguments
     static VArgVector im_filenames, cmd_filenames;
     static VBoolean im_found, cmd_found;

     // Below is a vista structure that specifies the valid 
     // command-line options for this program
     // The structure specifies that there is only one command-line 
     // argument, which is optional, and takes a list of vista images. 
     // Command-line invocation of the program will be:
     //     imdraw -in <image-1> <image-2> ...
     // Run 'man VParseCommand' and 'man Voption' for more information

     static VOptionDescRec options[] = {
        { "im", VStringRepn, 0, & im_filenames, & im_found, NULL,
	  "Image to display in OpenGL panel" },
        { "cmd", VStringRepn, 0, & cmd_filenames, & cmd_found, NULL,
	  "File that contains drawing commands" },
     };

     //
     // Parse the command line options
     //

     if (!VParseCommand(VNumber(options), options, argc, argv)) {
	  // Parsing failed, so print a command usage string
	  // This also happens if the '-help' option is given
	  VReportUsage(argv[0], VNumber(options), options, NULL);
	  exit(0);
     } 

     // If there are any unrecognized command line arguments, return
     // the usage string
     if (*argc > 1) {
	  // Print all unrecognized command-line arguments
	  VReportBadArgs(*argc, argv);
	  // Print a command usage string
	  VReportUsage(argv[0], VNumber(options), options, NULL);
	  exit(0);
     } 

     //
     // Process the input arguments
     //

     // 
     //  1. Perform error checking and read and display the image (if supplied)
     //

     if (im_found) {
	  // We can only display one image at a time, so if more than one 
	  // filename is supplied after '-im', we ignore all of them
	  // except the first one
	  if (im_filenames.number > 1) {
	       cerr << argv[0] << ": Multiple filenames after -im option: ignoring all but 1st\n";
	       cerr.flush();
	  } 	  
	  // If a filename was supplied, read the image(s) it contains
	  if (im_filenames.number > 0) {
		   char *fname;
		   fname = ((char **) im_filenames.vector)[0];
	       openImage(argv[0], fname, window);
	  }

	 }

     // 
     //  2. Perform error checking and execute drawing commands from
     //  the file (if supplied)
     //
     if (cmd_found) {
	  // We will only execute commands from one file at a time, so
	  // if more than one filename is supplied after '-cmd', we
	  // ignore all of them except the first one
	  if (cmd_filenames.number > 1) {
	       cerr << argv[0] << ": Multiple filenames after -cmd option: ignoring all but 1st\n";
	       cerr.flush();
	  } 
	  // If a filename was supplied, process the commands it contains
	  if (cmd_filenames.number > 0) {
		  char *fname;
		  fname = ((char **) cmd_filenames.vector)[0];
		  processDrawingCommands(argv[0], fname, window);
	  }
     }
}


// Function for displaying a Vista image in the GL panel
// This is done by the set() method in the last line of this function
void openImage(char* progname, char* filename, ScissorUI& window)
{
	 FILE *imfile;
	 VAttrList attributes;
	 VImage* images;
	 int nimages=0;
	       
#ifdef _WIN32
	 // In VC++ we need to specify that the image file should be
     // opened in binary (untranslated) mode 
	 if ((imfile = fopen(filename, "rb")) == NULL)
#else
     if ((imfile = fopen(filename, "r")) == NULL)
#endif
	      cerr << progname << ": Error opening file " 
		       << filename << "\n";
	 else if ((nimages = VReadImages(imfile, &attributes, &images)) == 0)
		  cerr << progname << ": Error reading images from file "
			   << filename << "\n";
	 else
	      // if at least one valid image was read, display it in the frame
	      window.set(images[0]);
}


