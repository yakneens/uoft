// Sample code that utilizes the C++ STL priority queue implementation
//
//    See http://www.fifi.org/doc/stl-manual/html/priority_queue.html
//    for more information

#include <queue>
#include <iostream>

using namespace std;

// Define a class that defines the elements of the priority queue
class PQElement {
     int _priority; // this will be the value used for sorting elements
     double _test;
public: 
     PQElement() {_priority=0;};
     PQElement(const PQElement & n) 
                   { _priority = n._priority; _test = n._test; };
     int & priority() 
                   { return(_priority); };
     int priority() const 
                   { return(_priority); };
     bool less(PQElement& n1, PQElement& n2)
                   { return(n1.priority() < n2.priority()); };
     bool operator<(const PQElement & n1) const 
                   { return _priority < n1.priority(); };
};

void main()
{
     PQElement n;
     int i;

     // Declare a variable-length priority queue with elements of 
     // class PQElement
     priority_queue<PQElement> a;

     // Insert 100 elements into the priority queue
     for (i=1; i<=100; i++) {
	  // set the priority 
	  n.priority() = -i;
	  // insert it into the priority queue
       	  a.push(n);
     }

     // Extract the elements from the priority queue
     while (!a.empty()) {
	  // print the priority of the highest-priority element
	  cout << (a.top()).priority() << "\n"; 
	  cout.flush();
	  // remove the highest-priority element from the queue
	  a.pop();
     }
}
