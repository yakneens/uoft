

class LODSlider : Fl_Value_Slider{



};