// DO NOT MODIFY THIS FILE!!!!!!
//
// (c) Kyros Kutulakos 06/01/04
//
// This file gives an example of how an image can be displaed in an
// OpenGL panel which is part of an fltk window
//
// The idea behind the image display code below is to display an image
// by drawing a rectangle on the screen whose dimensions are equal to
// the initial size of the OpenGL panel. Rather than giving the
// rectangle a single color, however, we texture-map the Vista image
// to be displayed in that rectangle.
//
// Doing the image display in this way will be useful for a number of
// assignments later on, because it allows us to shrink, distort,
// enlarge, or warp an image by simply changing the size and position
// of the rectancle's 4 vertices.
//
// To better understand the code in this file, you may want to refer
// to the Texture Mapping section of the OpenGL programming guide

#include "stdafx.h"
#include <math.h>
#include <iostream.h>
#include "c-code/imdraw.h"
#include "glutils.h"
#include <float.h>
#include <queue>
#include <vector>
#include "c-code/pqelement.h"
#include <assert.h>
#include "c-code/point.h"
#include "c-code/boundary.h"
#include <ctime>
#include <limits>

#define NORTH_WEST 0
#define NORTH 1
#define NORTH_EAST 2
#define WEST 3
#define EAST 4
#define SOUTH_WEST 5
#define SOUTH 6
#define SOUTH_EAST 7

using namespace std;

#define nbrPos(src_ind, dst_ind, dir) \
	switch(dir){ \
		/* North west */ \
		case 0: \
		{ \
			if(floor(src_ind / ncols) == 0 || (src_ind % ncols) == 0){ \
				dst_ind = INT_MAX; \
			}else{ \
				dst_ind = src_ind - ncols - 1; \
			}\
			break; \
		} \
		/* North */ \
		case 1: \
		{ \
			if(floor(src_ind / ncols) == 0){ \
				dst_ind = INT_MAX; \
			}else{ \
				dst_ind = src_ind - ncols; \
			} \
			break; \
		} \
		/* North east */ \
		case 2: \
		{ \
			if(floor(src_ind / ncols) == 0 || (src_ind % ncols) == ncols - 1){ \
				dst_ind = INT_MAX; \
			}else{ \
				dst_ind = src_ind - ncols + 1; \
			} \
			break; \
		} \
		/* east */ \
		case 3: \
		{ \
			if((src_ind % ncols) == ncols - 1){ \
				dst_ind = INT_MAX; \
			}else{ \
				dst_ind = src_ind + 1; \
			} \
			break; \
		} \
		/* south east */ \
		case 4: \
		{ \
			if(floor(src_ind / ncols) == nrows - 1 || (src_ind % ncols) == ncols - 1){ \
				dst_ind = INT_MAX; \
			}else{ \
				dst_ind = src_ind + ncols + 1; \
			} \
			break; \
		} \
		/* south */ \
		case 5: \
		{ \
			if(floor(src_ind / ncols) == nrows - 1){ \
				dst_ind = INT_MAX; \
			}else{ \
				dst_ind = src_ind + ncols; \
			} \
			break; \
		} \
		/* south west */ \
		case 6: \
		{ \
			if(floor(src_ind / ncols) == nrows - 1 || (src_ind % ncols) == 0){ \
				dst_ind = INT_MAX; \
			}else{ \
				dst_ind = src_ind + ncols - 1; \
			} \
			break; \
		} \
		/* west */ \
		case 7: \
		{ \
			if((src_ind % ncols) == 0){ \
				dst_ind = INT_MAX; \
			}else{ \
				dst_ind = src_ind - 1; \
			} \
			break; \
		} \
	}\

#define pVal(ptr) *(ptr + ppos)
#define qVal(ptr) *(ptr + qpos)


// Sets the image being displayed in the window
void ImDraw::set(VImage new_im)
{
     if ((VImageNRows(new_im) < 1) || (VImageNColumns(new_im) < 1)) {
	  return;
     }
     
     // Direct all further OpenGL commands to this OpenGL panel
     // This is NECESSARY if there are more than one OpenGL panels on 
     // the screen!
     make_current();
     if (imTexture == NULL) {
	  // These commands are executed only once, when the variable
	  // containing the image to be displayed points to a valid
	  // Vista image.  The command initializes the OpenGL
	  // texturing operations
	  
	  // Allocate space in texture memory for a single texture
	  // that has a maximum size of 1024x1024
	  
	  // Note that texture dimensions have to be powers of 2 and
	  // that the dimensions of any Vista image to be used as
	  // texture must have dimensions smaller than the texture
	  // dimensions.
	  
	  // You will need to call this routine with different
	  // parameters if you are to display Vista images larger than
	  // 1024x1024 (this is probably large enough and you might
	  // want to use smaller images to conserve memory & disk
	  // space
	  texture_set_globals(1024, 1024, 1);
          imTexture = new Texture(new_im);
	} else
	  imTexture->refresh(new_im);
     
     aspect_ratio = VImageNColumns(new_im)*1.0/VImageNRows(new_im);
     im_height = VImageNRows(new_im);
     im_width = VImageNColumns(new_im);

     // compute the magnification factor of the Vista image

     // define the width and height of the canvas area that will be
     // occupied by the displayed image, in order to preserve the
     // image's aspect ratio (which may be different from the aspect
     // ratio of the canvas window)
     double vh, vw;

     vh = (height < width/aspect_ratio)?height:(width/aspect_ratio);
     vw = vh*aspect_ratio;
     
     // Return the magnification factor of the image being
     // displayed. This is important if we want to get the coordinates
     // of the drawn rectangle to match pixel coordinates of the Vista
     // image being drawn
     magnification = vw/im_width;
     
     // Redraw the entire window to show the new image
     Fl_Window::redraw();
}
	
// Converts GL canvas coordinates to Vista coordinates. Vista
// coordinates are integers so that they can be used as indices into a
// Vista image array.  The function returns 1 if the GL coordinates
// corresponds to a point within the image boundary
int ImDraw::gl2vista(double glx, double gly, int& r, int& c)
{
     r = (int) rint(gly/magnification);
     c = (int) rint(glx/magnification);

     if ((r >= 0) && (r < im_height) && (c >= 0) && (c < im_width))
	  return 1;
     else 
	  return 0;
}

// Converts Vista coordinates to GL canvas coordinates
int ImDraw::vista2gl(int r, int c, double& glx, double& gly)
{
     gly = r*magnification;
     glx = c*magnification;

     if ((gly >= 0) && (gly < height) || (glx >= 0) && (glx < width))
	  return 1;
     else 
	  return 0;
}

// Displays a Vista image in a GL panel.  The image is displayed by
// texture-mapping it onto a polygon whose size is equal to the size
// of the GL panel
void ImDraw::draw_image()
{
     double tex_width, tex_height;
     double w, h;
     
     // texture-map polygons with the current texture
     if (imTexture != NULL) {
	  // Record the texture coordinates of the top-right corner of
	  // the image
	  imTexture->get_bounds(tex_width, tex_height);
	  // Enable GL texture mapping
	  imTexture->activate();
     }
  
     // define the width and height of the canvas area that will be
     // occupied by the displayed image, in order to preserve the
     // image's aspect ratio (which may be different from the aspect
     // ratio of the canvas window)
     h = (height < width/aspect_ratio)?height:(width/aspect_ratio);
     w = h*aspect_ratio;
  
     // The following statements are what actually display the image
     // in the panel.  The statements draw a rectangle defined by
     // (0,0) and (w, h); this rectangle is texture-mapped with a
     // rectangular image whose texture coordinates are defined by
     // (0,0) and (tex_width, tex_height)
 
     glColor3d(0.0, 0.0, 0.0);
     glBegin(GL_POLYGON);
     {
	  glTexCoord2d(0,0);
	  glVertex2d(0,h);
	  
	  glTexCoord2d(0,tex_height);
	  glVertex2d(0,0);
	  
	  glTexCoord2d(tex_width, tex_height);
	  glVertex2d(w, 0);
	  
	  glTexCoord2d(tex_width,0);
	  glVertex2d(w, h);
     }
     glEnd();
     glFlush();
     
     // Disable texture mapping for the OpenGL commands that follow
     if (imTexture != NULL) {
	  imTexture->deactivate();
     }
}


// Routine that intercepts window resize operations performed by the user
void ImDraw::resize(int x, int y, int w, int h)
{
     
     // the window has been resized so we need to update the width & height 
     // information 
     width = w;
     height = h;

     // Need to call this method ensure that the GL panel "knows" that
     // it has been resized as well...
     Fl_Gl_Window::resize(x, y, w, h);

     // determine the new magnification of the Vista image

     // define the width and height of the canvas area that will be
     // occupied by the displayed image, in order to preserve the
     // image's aspect ratio (which may be different from the aspect
     // ratio of the canvas window)
     double vh, vw;
     vh = (height < width/aspect_ratio)?height:(width/aspect_ratio);
     vw = vh*aspect_ratio;
     
     // Return the magnification factor of the image being
     // displayed. This is important if we want to get the coordinates
     // of the drawn rectangle to match pixel coordinates of the Vista
     // image being drawn
     magnification = vw/im_width;
}
VImage ImDraw::rgbToGrayscale(VImage img){
	/* Convert to grayscale. */	
	if(VImageNBands(img) == 3){
		VImage myImage = VCreateImage(1, VImageNRows(img), VImageNColumns(img),VUByteRepn);

		for(int i = 0; i < VImageNRows(img); i++){
			for(int j = 0; j < VImageNColumns(img); j++){
				
				VPixel(myImage, 0, i, j, VUByte) = 
					floor((double)((VPixel(img, 0, i, j, VUByte) + 
					 VPixel(img, 1, i, j, VUByte)  + 
					 VPixel(img, 2, i, j, VUByte)) / 3));

			}
		}
	return myImage;
	}else{
		return img;
	}
}

VImage ImDraw::zeroCrossings(VImage img, int sigma){

	double sigma2 = sigma / sqrt((double)(2)), sigma3 = sqrt((double)(2)) * sigma;
	double maxRange = -128, minRange = 127;
			
	if(sigma2 < 1){ sigma2 = 1;}
	if(sigma3 < 1){ sigma3 = 1;}

	
	/* Convert image to signed byte representation. */
	//VImage imgSigned = VConvertImageRange(img, NULL, VAllBands, VSByteRepn);
	VImage imgSigned = VConvertImageLinear(img, NULL, VAllBands, VSByteRepn, 1, -128);
	
	
	/* Compute two gaussian smoothed versions of the image */
	VImage gaussSmoothImg = 
		VGaussianConvolveImage(imgSigned, NULL, VAllBands, sigma2, ceil(6 * sigma2), VFilterGaussian);
	VImage gaussSmoothImg2 = 
		VGaussianConvolveImage(imgSigned, NULL, VAllBands, sigma3, ceil(6 * sigma3), VFilterGaussian);
	
	VImage laplImg = VImageOpI(gaussSmoothImg, NULL, VAllBands, VImageOpSub, gaussSmoothImg2, VAllBands, &maxRange, &minRange);

	/* Find the zero crossings in resulting image. */
	VImage zeroCrossImg = VZeroCrossings(laplImg, NULL, VAllBands);


	/* Convert image back to unsigned byte representation. */
	//VImage zeroCrossUnsigned = VConvertImageRange(zeroCrossImg, NULL, VAllBands, VUByteRepn);
	VImage zeroCrossUnsigned = VConvertImageLinear(zeroCrossImg, NULL, VAllBands, VUByteRepn, 1, 128);
	
	VDestroyImage(imgSigned);
	VDestroyImage(gaussSmoothImg);
	VDestroyImage(gaussSmoothImg2);
	VDestroyImage(laplImg);
	VDestroyImage(zeroCrossImg);

	return zeroCrossUnsigned;

}

VImage ImDraw::gradient(VImage img){
	
	/* Compute image gradient. */
	VImage gradImage = VImageGradient(img, NULL, VAllBands);
	
	
	return gradImage;
}

VImage ImDraw::gradientMagnitude(VImage img){
	
	
	/* Compute magnitudes of the image gradient. */
	VImage gradMagImage = VImageMagnitude(img, NULL, VAllBands);
	return gradMagImage;
}

VDouble ImDraw::gradMagMax(VImage img){
	
	VDouble magMax = 0;

	/* Compute maximum gradient magnitude in the image. */
	if(!VImageStats(img, VAllBands, NULL, &magMax, NULL, NULL)){
		exit(1);
	}

	return magMax;
}

void ImDraw::setDisplayState(int state){
	this->displayState = state;


}

int ImDraw::getDisplayState(){
	return this->displayState;
}


void ImDraw::pathFinderReInit(){
	VDouble *totalCost, *ancest;
	VBit *valid, *active, *processed;
	int npixels;
	if(!VSelectBand("Link Weights", nodeImage, 0, &npixels, (VPointer*)&totalCost))
			VError("Could not get band %d of gradient image", 0);
	if(!VSelectBand("Link Weights", nodeImage, 1, &npixels, (VPointer*)&ancest))
			VError("Could not get band %d of gradient image", 1);
	if(!VSelectBand("Link Weights", nodeInfoImage, 0, &npixels, (VPointer*)&valid))
			VError("Could not get band %d of gradient image", 0);
	if(!VSelectBand("Link Weights", nodeInfoImage, 1, &npixels, (VPointer*)&active))
			VError("Could not get band %d of gradient image", 1);
	if(!VSelectBand("Link Weights", nodeInfoImage, 2, &npixels, (VPointer*)&processed))
			VError("Could not get band %d of gradient image", 2);

	/* Reinitialize image nodes. */
	for(int i = 0; i < npixels; i++){
		*(totalCost++) = DBL_MAX;
		*(ancest++) = 0;
		*(valid++) = 1;
		*(active++) = 0;
		*(processed++) = 0;
	}
}

/* Computes link costs in im. */
void ImDraw::computeLinkCosts(VImage im){
	clock_t start = clock();

	/* Convert image to grayscale. */	
	VImage grayImg = rgbToGrayscale(im);
	
	//set(grayImg);
	this->grayImage = grayImg;
	/* Compute zero-crossings of the second derivative. */
	VImage zeroCross = zeroCrossings(grayImg, 1);
	this->zeroImage = zeroCross;
	
	VImage gradientImage = gradient(grayImg);
	

	/* Compute the image gradient magnitude. */
	VImage gradMagImage = gradientMagnitude(gradientImage);
	this->gradImage = gradMagImage;
	
	/* Compute the maximum gradient magnitude in the image. */
	VDouble maxMag = gradMagMax(gradMagImage);

	/* Number of rows in current image. */
	int nrows = VImageNRows(im);

	/* Number of columns in current image. */
	int ncols = VImageNColumns(im);

	int npixels, nzpixels;
	VPointer p;
	VSByte *gx, *gy, *gm;
	VUByte *z;
	VBit *active, *processed, *valid;
	VDouble  *totalCost, *ancest, *weightPtr[8];
	int qpos, xpos, ypos;
	
	/* Create image to store link weights. */
	VImage linkWeights = VCreateImage(8, nrows, ncols, VDoubleRepn);

	/* Create image to store link weights. */
	VImage nodes = VCreateImage(2, nrows, ncols, VDoubleRepn);

	VImage nodeInfo = VCreateImage(3, nrows, ncols, VBitRepn);

	/* Get pointers to image pixels for link weight image. */
	for(int w = 0; w < 8; w++){
		if(!VSelectBand("Link Weights", linkWeights, w, &npixels, (VPointer*)&weightPtr[w]))
			VError("Could not get band %d of link cost image", w);
	}
	if(!VSelectBand("Link Weights", nodes, 0, &npixels, (VPointer*)&totalCost))
		VError("Could not get band %d of node image", 0);

	if(!VSelectBand("Link Weights", nodes, 1, &npixels, (VPointer*)&ancest))
		VError("Could not get band %d of node image", 1);

	if(!VSelectBand("Link Weights", nodeInfo, 0, &npixels, (VPointer*)&valid))
		VError("Could not get band %d of nodeInfo image", 0);

	if(!VSelectBand("Link Weights", nodeInfo, 1, &npixels, (VPointer*)&active))
		VError("Could not get band %d of nodeInfo image", 1);

	if(!VSelectBand("Link Weights", nodeInfo, 2, &npixels, (VPointer*)&processed))
		VError("Could not get band %d of nodeInfo image", 2);

	double dpNorm[2], dqNorm[2], lpq[2], qToP[2], dotPr, dSubP, dSubQ;
	double gradDirTerm, zeroCrossTerm = 1, gradMagTerm, scalingFactor = 1;
	
	/* Get pointer to the pixels in frist band of gradient image. */
	if(!VSelectBand("Gradient X", gradientImage, 0, &npixels, (VPointer*)&gx))
		VError("Could not get band 0 of gradient image");
	/* Get pointer to the pixels in second band of gradient image. */
	if(!VSelectBand("Gradient Y", gradientImage, 1, &npixels, (VPointer*)&gy))
		VError("Could not get band 1 of gradient image");
	/* Get pointer to pixels in the zero crossing image. */
	if(!VSelectBand("Zero Crossing", zeroCross, 0, &nzpixels, (VPointer*)&z))
		VError("Could not get band 0 of zero crossing image");
	/* Get pointer to pixels in the gradient magnitude image. */
	if(!VSelectBand("Gradient Magnitude", gradMagImage, 0, &npixels, (VPointer*)&gm))
		VError("Could not get band 0 of gradient magnitude image");
	
	/* For each pixel in the image. */
	for(int ppos = 0; ppos < npixels; ppos++){
		
		/* Determine x and y coordinates of the pixel. */
		xpos = ppos % ncols;
		ypos = (int)floor((double)(ppos / ncols));
		
		
		/* Normalize the gradient and obtain a vector orthogonal to it. */
		dpNorm[0] = pVal(gm) > 0 ? (pVal(gx) / pVal(gm)) : 0;
		dpNorm[1] = pVal(gm) > 0 ? -1 * (pVal(gy) / pVal(gm)) : 0;
		
		/* For each neighbour of current pixel. */
		for(int j = 0; j < 8; j++){
			/* Set pointer to first pixel in gradient magnitude image. */
			
			/* Initialize scaling factor for gradient magnitude. */
			scalingFactor = 1;

			/* Obtain pointers to gradient pixels, and gradient magnitude
			   of current neighbour. Obtain pixel position of current neighbour. */
			nbrPos(ppos, qpos, j);
			
			/* If neighbour is within image boundary. */
			if(qpos != INT_MAX){
				
				int xposq = (qpos % ncols);
				int yposq = floor((double)(qpos / ncols));
				
				/* Calculate vector between this pixel and current neighbour. */
				qToP[0] = xposq - xpos;
				qToP[1] = yposq - ypos;

				/* Normalize the gradient for current neighbour
				   and obtain a vector orthogonal to it. */
				dqNorm[0] = qVal(gm) > 0 ? (qVal(gx) / qVal(gm)) : 0;
				dqNorm[1] = qVal(gm) > 0 ? -1 * (qVal(gy) / qVal(gm)) : 0;
				
				/* <D(p) | q - p> */
				dotPr = dpNorm[0] * qToP[0] + dpNorm[1] * qToP[1];
				
				/* Compute biderectional link between current pixel and
				   current neighbour. */
				if(dotPr >= 0){
					lpq[0] = qToP[0];
					lpq[1] = qToP[1];
					dSubP = dotPr;
				}else{
					lpq[0] = -1 * qToP[0];
					lpq[1] = -1 * qToP[1];

					dSubP = dpNorm[0] * lpq[0] + dpNorm[1] * lpq[1];
				}
				
				/* <D(q) | L(p,q)> */
				dSubQ = abs(dqNorm[0] * lpq[0] + dqNorm[1] * lpq[1]);
			
				/* Calculate the gradient direction term of the link weight. */
				gradDirTerm = (double)((2 * (acos(dSubP) + acos(dSubQ))) / (3 * PI));

				if(_isnan(gradDirTerm)){
					gradDirTerm = 0.5;
				}

				assert(gradDirTerm >= 0 && gradDirTerm <= 1);

				if(xposq > 0 && yposq > 0){
					int zeroCorssIndex = (yposq - 1) * im_width + xposq - 1;
					
					/* Calculate the zero crossing term of the link weight. */
					if(*(z + zeroCorssIndex) > 0){
						zeroCrossTerm = 0;
					}
				}

				assert(zeroCrossTerm >= 0 && zeroCrossTerm <= 1);

				/* Update scaling factor depending on whether the neighbour is diagonal. */
				if((j % 2) != 0){
					scalingFactor /= sqrt((double)2);
				}

				/* Compute the gradient magnitude term of the link weight. */
				gradMagTerm = scalingFactor * (1 - (qVal(gm) / maxMag));
				
				assert(gradMagTerm >= 0 && gradMagTerm <= 1);
				
				double linkWeight = 0.43 * zeroCrossTerm + 0.00 * gradDirTerm + 0.43 * gradMagTerm;
				assert(linkWeight >= 0 && linkWeight <= 1);
					
					/* Set the link weight to the computed value and advance one pixel. */
				pVal(weightPtr[j]) = linkWeight;
					
					
			}
		}
		
		/* Advance pointers by one pixel. */
		*(totalCost++) = DBL_MAX;
		*(ancest++) = 0;
		*(valid++) = 1;
		*(active++) = 0;
		*(processed++) = 0;
	}

	this->weightImage = linkWeights;
	this->nodeImage = nodes;
	this->nodeInfoImage = nodeInfo;
	
	cout << "Link Weight time: " << clock() - start  << " clock ticks \n";
	cout.flush();

	
}

void ImDraw::computePathCosts(int seedX, int seedY){
	clock_t start = clock();
	int npixels, pixelPos = this->im_width * seedY + seedX;
	VDouble *weightPtr[8], *totalCost, *ancest;
	VBit *active, *processed, *valid;
	VDouble *totalCostInit, *ancestInit, *activeInit, *processedInit, *validInit;
	int nrows = this->im_height, ncols = this->im_width, nbrPixelPos;

	/* Get pointers to image pixels for link weight image. */
	for(int w = 0; w < 8; w++){
		if(!VSelectBand("Link Weights", weightImage, w, &npixels, (VPointer*)&weightPtr[w]))
			VError("Could not get band %d of gradient image", w);
		
	}
	
	if(!VSelectBand("Link Weights", nodeImage, 0, &npixels, (VPointer*)&totalCost))
			VError("Could not get band %d of gradient image", 0);
	/*totalCostInit = totalCost;
	totalCost += pixelPos;*/

	if(!VSelectBand("Link Weights", nodeImage, 1, &npixels, (VPointer*)&ancest))
			VError("Could not get band %d of gradient image", 1);
	/*ancestInit = ancest;
	ancest += pixelPos;*/

	if(!VSelectBand("Link Weights", nodeInfoImage, 0, &npixels, (VPointer*)&valid))
			VError("Could not get band %d of gradient image", 0);
	/*validInit = valid;
	valid += pixelPos;*/

	if(!VSelectBand("Link Weights", nodeInfoImage, 1, &npixels, (VPointer*)&active))
			VError("Could not get band %d of gradient image", 1);
	/*activeInit = active;
	active += pixelPos;*/

	if(!VSelectBand("Link Weights", nodeInfoImage, 2, &npixels, (VPointer*)&processed))
			VError("Could not get band %d of gradient image", 2);
	
	/* New active list. */
	priority_queue<PQElement> activeList;
	
	/* Set the active flag on this pixel's node. */
	*(active + pixelPos) = 1;
	*(totalCost + pixelPos) = 0;

	/* Create a new queue element containing a pointer to this pixel
	   with priority set to this pixel's cost. */
	PQElement topElem(pixelPos, 0);
	
	/* Insert new element into the queue. */
	activeList.push(topElem);

	
	/* Process all elements in the active list. */
	while(!activeList.empty()){
		
		/* Retreive the node pointer contained in top element. */
		pixelPos = activeList.top().getPixelIndex();
			
		/* If top element is valid. */
		if(*(valid + pixelPos)){

			
			*(valid + pixelPos) = 0; 


			/* Pop the top element off the queue. */
			activeList.pop();

			/* Set this node as processed. */			
			*(processed + pixelPos) = 1;
			*(active + pixelPos) = 0;
			
			/* Go through all the neighbours. */
			for(int i = 0; i < MAX_NEIGHBOURS; i++){

				/* Current neighbour. */
				nbrPos(pixelPos, nbrPixelPos, i);
				
				/* If neighbour represents a valid pixel. */
				if(nbrPixelPos != INT_MAX){
					/* If neighbour is not yet processed. */
					if(!*(processed + nbrPixelPos)){
						double tempCost;

						if(*(totalCost + pixelPos) == DBL_MAX){
							tempCost = *(weightPtr[i] + pixelPos);
						}else{
							/* Compute current estimated minimal cost from seed to neighbour. */
							tempCost = *(totalCost + pixelPos) + *(weightPtr[i] + pixelPos);
						}
						
						/* If neighbour already on active list and the new cost
						   is lower than the previously computed cost. */
						if(*(active + nbrPixelPos) && tempCost < *(totalCost + nbrPixelPos)){
							
							*(active + nbrPixelPos) = 0;
						}
						
						/* If neighbour is not on the active list. */
						if(!*(active + nbrPixelPos)){

							/* Flag neighbour as being on the active list. */
							*(active + nbrPixelPos) = 1;

							/* Set the cost to the new estimated cost. */
							*(totalCost + nbrPixelPos) = tempCost;
							
							/* Set the node's ancestor. */
							*(ancest + nbrPixelPos) = pixelPos;
							
							/* Create a new queue element containing a pointer to 
							   neighbour with cost tempCost. */
							PQElement newElem(nbrPixelPos, tempCost);

							/* Insert the new element into the queue. */
							activeList.push(newElem);
						}
					}
				}
			}
		/* The element is not valid so simply remove it from the queue. */
		}else{
			activeList.pop();
		}
	}
	
	cout << "Path cost time: " << clock() - start  << " clock ticks \n";
	cout.flush();
}


int ImDraw::getImageWidth(){
	return this->im_width;
}

int ImDraw::getImageHeight(){
	return this->im_height;
}

/* Create an image containing boundary. */
VImage ImDraw::getBoundary(ImagePrimitive *boundary){
	
	Boundary *myBoundary = (Boundary*)boundary;
	
	/* Band 1 is used to store pixel values. Band 2 is used to store information about
	   pixels to be used in computing the alpha matte. */
	VImage boundaryImg = VCreateImage(2, this->im_height, this->im_width, VUByteRepn);
	
	std::deque<Point>::iterator it;
	
	Point* pt;
	
	bool flag = true;

	/* Zero in the image. */
	VFillImage(boundaryImg, VAllBands, 0);
	
	Point prev = *(myBoundary->getVerticesEnd()), next = *(myBoundary->getVerticesBegin() + 1);
	
	/* Go through all the vertices on the boundary. */
	for(it = myBoundary->getVerticesBegin(); it < myBoundary->getVerticesEnd(); it++){
		Point thisPixel = *it;
		
		/* Set the corresponding pixel in the image to intensity 255. */
		VPixel(boundaryImg, 0, thisPixel.getY(), thisPixel.getX(), VUByte) = 255;
		
		/* Look at the previous and the next vertex. */
		if((it + 1) != myBoundary->getVerticesEnd()){
			next = (*it);
			//it--;
		}else{
			next = *(myBoundary->getVerticesBegin());
		}
		
		/* In this case we should not flip the parity bit when scan converting the alpha
		   matte. */
		if((prev.getY() < thisPixel.getY() && 
		    prev.getX() < thisPixel.getX() && 
		    next.getY() < thisPixel.getY() &&
		    next.getX() > thisPixel.getX())){
			VPixel(boundaryImg, 1, thisPixel.getY(), thisPixel.getX(), VUByte) = 1;
		}else if(prev.getY() > thisPixel.getY() &&
		    prev.getX() < thisPixel.getX() &&
			next.getY() > thisPixel.getY() &&
			next.getX() > thisPixel.getX()){
			VPixel(boundaryImg, 1, thisPixel.getY(), thisPixel.getX(), VUByte) = 2;
		}else if((prev.getX() < thisPixel.getX() &&
			  prev.getY() == thisPixel.getY() &&
			  next.getX() > thisPixel.getX() &&
			  next.getY() == thisPixel.getY())){
			VPixel(boundaryImg, 1, thisPixel.getY(), thisPixel.getX(), VUByte) = 3;
		}else{
			VPixel(boundaryImg, 1, thisPixel.getY(), thisPixel.getX(), VUByte) = 4;
		}
	}
	return boundaryImg;
}

/* Computes the alpha matte based on the boundary. */
VImage ImDraw::getMatte(VImage boundary){
	
	int parity = 0;
	VImage matte = VCreateImage(1, this->im_height, this->im_width, VUByteRepn);
	VUByte flag;

	for(int i = 0; i < this->im_height; i++){
		parity = 0;
		for(int j = 0; j < this->im_width; j++){
			int val = VPixel(boundary, 0, i, j, VUByte);
			flag = VPixel(boundary, 1, i, j, VUByte);
			/* flag = 1 - max
			   flag = 2 - min
			   flag = 3 - horizontal edge
			   flag = 4 - other */
			if(val == 255 && parity == 0){
				if(flag == 4){
					parity = 1;
				}else if(flag == 3){
					cout << "3\n";
				}else if(flag == 2){
					cout << "2\n";
				}else if(flag == 1){
					cout << "1\n";
				}
				cout.flush();
				VPixel(matte, 0, i, j, VUByte) = 0;

			}else if(val == 255 && parity == 1){
				if(flag == 4){
					parity = 0;
				}if(flag == 3){
					cout << "3\n";
				}else if(flag == 2){
					cout << "2\n";
				}else if(flag == 1){
					cout << "1\n";
				}
				cout.flush();

				VPixel(matte, 0, i, j, VUByte) = 0;

			}else if(val == 0 && parity == 0){

			}else if(val == 0 && parity == 1){
				VPixel(matte, 0, i, j, VUByte) = 255;
				if(flag == 3){
					cout << "3\n";
				}else if(flag == 2){
					cout << "2\n";
				}else if(flag == 1){
					cout << "1\n";
				}
				cout.flush();
			}
		}

	}
	

	return matte;
}

/* Return string representation of the boundary vertices */
string ImDraw::writeBoundaryVertices(){
	ImagePrimitive *tempObj;
	
	for(int i = 0; i < this->sceneObjects.size(); i++){
		tempObj = sceneObjects[i];
		if(tempObj->getType() == ImagePrimitive::boundary){
			Boundary *myBoundary = (Boundary*)tempObj;
			return myBoundary->verticesToString();
		}
	}

	return "";
}

/* Return string representation of the boundary seed points */
string ImDraw::writeBoundarySeedPoints(){
	ImagePrimitive *tempObj;
	
	for(int i = 0; i < this->sceneObjects.size(); i++){
		tempObj = sceneObjects[i];
		if(tempObj->getType() == ImagePrimitive::boundary){
			Boundary *myBoundary = (Boundary*)tempObj;
			return myBoundary->seedPointsToString();
		}
	}

	return "";
}

/* Write alpha matte to file */
void ImDraw::writeMatteToFile(char* filename){
	Boundary *myBoundary;
	ImagePrimitive *tempObj;
	bool found = false;

	for(int i = 0; i < this->sceneObjects.size(); i++){
		tempObj = sceneObjects[i];
		if(tempObj->getType() == ImagePrimitive::boundary){
			myBoundary = (Boundary*)tempObj;
			found = true;
			break;
		}
	}

	if(found){
		VImage boundaryImage = this->getBoundary(myBoundary);
		VImage matte = this->getMatte(boundaryImage);

		FILE *fp;
	
		/* If a file has been successfully chosen, write the matte
		to the file. */
#ifdef WIN32
	fp = fopen(filename, "wb");
#else
	fp = fopen(filename, "w");
#endif
		VWriteImages(fp, NULL, 1, &matte);
		VDestroyImage(matte);
		fclose(fp);
	}
}

/* Write gradient image to file */
void ImDraw::writeGradToFile(char *filename){
		FILE *fp;
	
		/* If a file has been successfully chosen, write the matte
		to the file. */

#ifdef WIN32
	fp = fopen(filename, "wb");
#else
	fp = fopen(filename, "w");
#endif
		
		if(!VWriteImages(fp, NULL, 1, &this->gradImage)){
			exit(1);
		}
		fclose(fp);
	
}

/* Write zero crossing image to file */
void ImDraw::writeZeroCrossToFile(char *filename){
		FILE *fp;
	
		/* If a file has been successfully chosen, write the matte
		to the file. */

#ifdef WIN32
	fp = fopen(filename, "wb");
#else
	fp = fopen(filename, "w");
#endif
		VWriteImages(fp, NULL, 1, &this->zeroImage);
		fclose(fp);
}

/* Write link cost image to file */
void ImDraw::writeLinkCostsToFile(char *filename){
		FILE *fp;
	
		/* If a file has been successfully chosen, write the matte
		to the file. */

#ifdef WIN32
	fp = fopen(filename, "wb");
#else
	fp = fopen(filename, "w");
#endif		
		
		VWriteImages(fp, NULL, 1, &this->weightImage);
		fclose(fp);
}

void ImDraw::gl2v_matrices(Matrix& gl2v, Matrix& v2gl){
	// matrix mapping 2D OpenGL coordinates to 2D Vista coordianates
	gl2v.ReSize(2,2);
	gl2v(1,1) = 0;
	gl2v(1,2) = 1/magnification;
	gl2v(2,1) = 1/magnification;
	gl2v(2,2) = 0;

	// matrix mapping 2D OpenGL coordinates to 2D Vista coordianates
	v2gl.ReSize(2,2);
	v2gl(1,1) = 0;
	v2gl(1,2) = magnification;
	v2gl(2,1) = magnification;
	v2gl(2,2) = 0;
}


void ImDraw::setSlider(Fl_Value_Slider *slider){
	this->splineLOD = slider;
}
