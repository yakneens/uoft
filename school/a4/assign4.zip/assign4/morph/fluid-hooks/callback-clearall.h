/* Remove all objects from the scene and redraw. */
imagePanel->clearScene();
imagePanel->redraw();
