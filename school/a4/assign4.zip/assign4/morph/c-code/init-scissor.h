// Add here any initialization code you need to include in the
// ScissorUI constructor.

// The following variables are defined in the 
// ScissorUI class, using fluid

im=NULL;
attrs=NULL;

