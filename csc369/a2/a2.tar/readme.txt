Extract files from a2.tar

To compile all source type make

To compile bridge part 1 type make 1

To compile bridge part 2 type make 2

To compile bridge part 3 type make 3

To compile simulation part 1 type make s1

To compile simulation part 2 type make s2


Defects:
A defect in simulation parts 1 & 2 prevents some
processes from reaching DONE state. Not resolved
due to time constraints.